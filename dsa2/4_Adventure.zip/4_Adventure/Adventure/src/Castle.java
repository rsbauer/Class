import java.util.ArrayList;

/**
 * COPYRIGHT (C) 2005 Rob Bauer.  All Rights Reserved.
 * <br> <br>
 * An object to represent a game castle and the rooms it contains.  This object will behave (hopefully) as a graph.  The
 * rooms will be nodes of the graph.  The paths from room to room will be the edges between the nodes.
 * 
 * @author Rob Bauer
 * @version 1.0  2005-NOV-08
 */
public class Castle 
{
	/**
	 * Contain a list of rooms.
	 */
	private Room[] rooms;
	
	/**
	 * Contain a list of the arcs that connect the rooms.  Using an ArrayList because rooms will have a many-to-many
	 * relationship and the ArrayList will be able to grow to meet the demand. 
	 */
	private ArrayList arcs;
	
	/**
	 * Max number of rooms we'll need to keep track of.
	 */
	private final static int MAXNUMROOMS = 99;
	
	
	/**
	 * Keep track of the number of rooms 
	 */
	private int roomcount;
	
	/**
	 * Adjacency matrix to keep track of which rooms are adjacent to the other rooms. 
	 */
	private byte[][] adjacency;
	
	
	private enum Direction
	{
		N("North"),
		E("East"),
		S("South"),
		W("West");
		
		private final String fullName;
		
		private Direction(String name)
		{
			fullName = name;
		}  // end public Direction(String name)
		
	};  // end public enum Direction
	
	
	/**
	 * Initialize the castle variables. 
	 */
	public Castle()
	{
		// Initialize the vector to the max number of rooms - if a really large number of rooms, then this 
		// plan may need rethinking
		rooms = new Room[MAXNUMROOMS];
		arcs = new ArrayList();
		roomcount = 0;
		adjacency = null;
	}  // end public Castle()
	
	
	/**
	 * Add a room to the castle.  
	 * 
	 * @param roomNumber int the room number 
	 * @param roomName String the room's name
	 * @return new room which was created
	 */
	public Room addRoom(int roomNumber, String roomName)
	{
		// TODO:  Add a room - Add the room object to an array like object (array list sounds good)
		Room room = new Room(roomNumber, roomName);

		try
		{
			rooms[roomNumber] =  room;			// assign the room to the vector via its room ID number
		}  // end try
		catch(Exception e)
		{
			System.out.println("Failed to add room " + roomName + " (" + roomNumber + "): " + e);
			return null;
		}  // end catch(Exception e)
		
		roomcount++;
		return room;
	}  // end public void addRoom(String roomID, String roomName)
	
	
	/**
	 * Add an arc to the castle.  One arc describes a connection between two rooms.
	 * 
	 * @param roomSource int specifies the index location of the source room
	 * @param roomDestination int specifies the index location of the destination room
	 * @param arcLabel String containing the arc label (which turns out to be the direction of the arc)
	 */
	public void addArc(String arcLabel, int roomSource, int roomDestination)
	{
		Arc arc = new Arc(arcLabel, rooms[roomSource], rooms[roomDestination]);
		arcs.add(arc);
	}  // end public void addArc(int roomSource, int roomDestination, String arcLabel)
	
	
	/**
	 * Return the number of rooms currently in the castle.
	 * 
	 * @return int number of rooms
	 */
	public int roomCount()
	{
		return roomcount;
	}  // end public int roomCount()
	
	
	
	/**
	 * Build the adjacency matrix.  Before doing so, the castle must have some rooms. 
	 */
	public void buildMatrix()
	{
		adjacency = new byte[roomcount][roomcount];						// define a new matrix
//		adjacency = clearMatrix(new byte[roomcount][roomcount]);		// clear the matrix and set the values to 0
		Arc arc = null;
		int source;
		int destination;
			
		// loop through the arcs and for each connection, make the association in the adjacency matrix
		for(int a = 0; a < arcs.size(); a++)
		{
			arc = (Arc) arcs.get(a);								// unpack the arc from the list
			source = arc.getSource().getRoomID();
			destination = arc.getDestination().getRoomID();
			
			adjacency[source][destination] = 1;
		}  // end for(int a = 0; a < arcs.size(); a++)
		
		// printAdjacency();										// for troubleshooting
	}  // end public void buildMatrix()
	
	
	private byte[][] clearMatrix(byte[][] matrix)
	{
		int count = matrix.length;
		for(int a = 0; a < count; a++)
			for(int b = 0; b < count; b++)
				matrix[a][b] = 0;
		return matrix;
	}  // end private void clearMatrix(byte[][] matrix)
	
	
	/**
	 * Print the adjacency matrix to the console.  This is for testing to validate the loading of the file and the 
	 * success (or lack thereof) of  
	 */
	private void printAdjacency()
	{
		StringBuffer output = new StringBuffer();
		int count = adjacency.length;
		for(int a = 0; a < count; a++)
		{
			for(int b = 0; b < count; b++)
				output.append(adjacency[a][b] + " ");
			System.out.println(output.toString());
			output = new StringBuffer();
		}  // end for(int a = 0; a < count; a++)
	}  // end private void printAdjacency()
	
	
	
	/**
	 * Provide debug output to the user interface.  To be used to verify the quality of the castle/rooms (aka: graph).
	 * 
	 * List rooms and their connections to other rooms.
	 */
	public String debug()
	{
		StringBuffer output = new StringBuffer();				// setup the string buffer to contain the output
		String roomname = new String();							// keep track of the current room
		int roomid = 0;											// keep track of the source's room ID
		Arc arc;												// the arc connecting the two rooms
		clearVisists();											// clear all visits
		
		// for each room, list all arcs
		for(int a = 0; a < roomcount; a++)
		{
			roomname = rooms[a].getName();						// this room's name
			roomid = rooms[a].getRoomID();						// this room's ID
			
			for(int b = 0; b < roomcount; b++)
			{
				if(adjacency[roomid][b] != 0)
				{
					arc = findArc(rooms[a], rooms[b]);
					// Direction.valueOf(arc.getLabel()).fullName <-- handles swapping the 1 character direction to 
					// the full name of the direction - for printing and making it look pretty.
					output.append(roomname + " " + Direction.valueOf(arc.getLabel()).fullName + " to " + 
							rooms[b].getName() + "\n");
				}  // end if(adjacency[a][b] != 0)
			}  // end for(int b = 0; b < roomcount; b++)
		}  // end for(int a = 0; a < roomcount; a++)
		
		return output.toString();
	}  // end public void debug()
	
	
	public Arc findArc(Room source, Room destination)
	{
		Arc arc = null;
		
		for(int a = 0; a < arcs.size(); a++)
		{
			arc = (Arc) arcs.get(a);
			if(arc.getDestination() == destination && arc.getSource() == source)
				return arc;
		}  // end for(int a = 0; a < arcs.size(); a++)
		
		return arc;
	}  // end private Arc findArc(Room source, Room destination)
	

	public ArrayList findArc(Room source)
	{
		ArrayList arclist = new ArrayList();
		Arc arc = null;
		
		for(int a = 0; a < arcs.size(); a++)
		{
			arc = (Arc) arcs.get(a);
			if(arc.getSource() == source)
				arclist.add(arc);
		}  // end for(int a = 0; a < arcs.size(); a++)
		
		return arclist;
	}  // end public Arc[] findArc(Room source)
	
	/**
	 * Reset all visists to rooms and arcs. 
	 */
	private void clearVisists()
	{
		for(int a = 0; a < roomcount; a++)
		{
			rooms[a].clearVisit();
		}  // end for(int a = 0; a < roomcount; a++)
		
		for(int a = 0; a < arcs.size(); a++)
		{
			((Arc) arcs.get(a)).clearTraversed();
		}  // end for(int a = 0; a < arcs.size(); a++)
	}  // end private void clearVisists()
	
	
	/**
	 * Convert a letter specifying a direction to its full name.
	 * 
	 * @param shortname string containing the short direction name
	 * @return String contaning the direction's full name
	 */
	public String getDirectionFullName(String shortname)
	{
		return Direction.valueOf(shortname).fullName;			// map the short name to the full name
	}  // end public Direction getDirection()
	
	
	public Room testMove(int currentroom, char direction)
	{
		Arc arc;
		for(int a = 0; a < arcs.size(); a++)
		{
			arc = (Arc) arcs.get(a);
			if(arc.getSource().getRoomID() == currentroom && arc.getLabel().equals("" + direction))
				return arc.getDestination();
		}  // end for(int a = 0; a < arcs.size(); a++)
		
		return null;
	}  // end public Room move(char direction)

}  // end public class Castle

