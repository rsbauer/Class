
/**
 * COPYRIGHT (C) 2005 Rob Bauer.  All Rights Reserved.
 * <br> <br>
 * Player object.  Used to keep track of the current room the player is in as well as the player's vitals (like health).   
 * 
 * @author Rob Bauer
 * @version 1.0  2005-NOV-12
 */
public class Player 
{
	private Room currentroom;
	private int health;
	
	/**
	 * Setup the player 
	 */
	public Player()
	{
		currentroom = null;										// don't know which room to start at 
		health = 100;											// start the user's health at 100 points
	}  // end public Player()
	
	
	/**
	 * Find out which room the user is currently in.
	 * 
	 * @return Room current room the user is in.
	 */
	public Room getCurrentRoom()
	{
		return currentroom;
	}  // end public Room getCurrentRoom()
	
	
	/**
	 * Set the current room as the room the user is currently in.
	 * 
	 * @param room Room the user is in.
	 */
	public void setCurrentRoom(Room room)
	{
		currentroom = room;
	}  // end public void setCurrentRoom()
	
}  // end public class Player
