/**
 * COPYRIGHT (C) 2005 Rob Bauer.  All Rights Reserved.
 * <br> <br>
 * An object to represent a castle room.  This object will behave (hopefully) as a node of a graph.  
 * 
 * @author Rob Bauer
 * @version 1.0  2005-NOV-08
 */
public class Room {

	/**
	 * Room ID (usually the room number) 
	 */
	private int roomID;
	
	/**
	 * Room name 
	 */
	private String name;
	
	/**
	 * Keep track if this room has been visited or not. 
	 */
	private boolean visited;

	// TODO: room properties needs to be stored somewhere like here
	
	
	/**
	 * Simple constructor to make a new room.
	 */
	public Room()
	{
		roomID = 0;
		name = "";
		visited = false;
	}  // end public Room()
	

	/**
	 * Constructor to make a new room.
	 * 
	 * @param number int of the room's ID
	 * @param roomname String of the room's name
	 */
	public Room(int number, String roomname)
	{
		roomID = number;
		name = roomname;
		visited = false;
	}  // end public Room(int number, String roomname)
	
	
	/**
	 * Return the room's ID
	 * 
	 * @return int containing the room's id
	 */
	public int getRoomID()
	{
		return roomID;
	}  // end public int getRoomID()
	
	
	/**
	 * Return the room's name.
	 * 
	 * @return String containing the room's name
	 */
	public String getName()
	{
		return name;
	}  // end public String getName()

	
	/**
	 * Clear the visit flag. 
	 */
	public void clearVisit()
	{
		visited = false;
	}  // end public void clearVisit()
	
	
	public boolean haveVisisted()
	{
		return visited;
	}  // end public boolean hasVisisted()
}  // end public class Room {



