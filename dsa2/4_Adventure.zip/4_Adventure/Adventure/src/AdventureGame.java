import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;

// TODO:  remove this comment
// Dijkstra's in action:  http://www.ifors.ms.unimelb.edu.au/tutorial/dijkstra/island.html

/**
 * COPYRIGHT (C) 2005 Rob Bauer.  All Rights Reserved.
 * <br> <br>
 * Handles game play, game rules, and setting up and maintaining the graph of rooms.
 * 
 * @author Rob Bauer
 * @version 1.0  2005-NOV-08
 */
public class AdventureGame extends JPanel implements KeyListener

{
	
	/**
	 * Default version ID 
	 */
	private static final long serialVersionUID = 1L;
	
	
	/**
	 * Game castle (mimics a graph) 
	 */
	private Castle castle;
	
	
	/**
	 * Keep track of the player's information 
	 */
	private Player player;
	
	
	/**
	 * Editor pane to display the game text 
	 */
	private JTextArea editorPane;
	
	
	/**
	 * Variable to keep track of the status bar label so it can be updated later on. 
	 */
	private JLabel statusbarlabel;
	
	/**
	 * Cursor prompt to display 
	 */
	private static final String CURSOR = ">> ";

	
	/**
	 * Welcome message text.  This is displayed to the user when they start the game. 
	 */
	private static final String WELCOMEMSG = "Welcome to Adventure!\n\nFor " +
			"help, press H\n\nThe king has requested your help.  You must retrieve his crown from the castle.  Watch" +
			" out for treasures and evil-doers.\n";  // You find yourself at the entrance hallway of the castle.\n
	

	public AdventureGame()
	{
		castle = null;
		player = new Player();
		
		// paint the GUI
		setupPanel();							// setup the window
		printMessage(WELCOMEMSG);			// display the welcome message
	}  // end public AdventureGame()
	
	/**
	 * Setup the window pane. 
	 * http://java.sun.com/docs/books/tutorial/uiswing/layout/gridbag.html
	 */
	private void setupPanel()
	{
		setOpaque(true);						// handy for clearing the panel successfully (otherwise get artifacts)

	    GridBagLayout gridbag = new GridBagLayout();					// define the layout - using gridbaglayout
	    GridBagConstraints c = new GridBagConstraints();				// initialize the constraints for this layout
	    		
		setLayout(gridbag);												// set the layout
		JPanel viewport = new JPanel();									// setup a new panel
		viewport.setLayout(new BorderLayout());							// set the layout for the panel
		
		JPanel statusbar = new JPanel();								// setup a panel for the status bar
		statusbar.setLayout(gridbag);									// use gridbag layout
		c.ipady = 2;													// some vertical padding
		statusbarlabel = new JLabel("Health:"); 						// create the label to go into the status bar 
		statusbar.add(statusbarlabel, c);								// add the label to the bar
		
		editorPane = createJEditorPane();								// create an editor pane
		JScrollPane editorScrollPane = new JScrollPane(editorPane);		// setup scroll bars for the editor pane
        editorScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);	// turn on vert. scrollbar
        viewport.add(editorScrollPane);									// add the editor to the panel
        
        c.fill = GridBagConstraints.BOTH;			// fill both vertical and horizontal spaces
        c.weightx = 1;								// use all horizontal grid space
        c.weighty = 1;								// use all vertical grid space
        c.gridx = 0;								// position at the left column
        c.gridy = 0;								// position in the first row
		c.ipady = 0;								// reset veritical padding
		
		add(viewport, c);							// add the panel to the current panel
        
		c.fill = GridBagConstraints.NONE;			// set to horizontal to align center and fill both sides
        c.anchor = GridBagConstraints.WEST;
        c.gridx = 0;								// position this in the first column of the grid
        c.gridy = 1;								// locate this item at row 2 of the grid
        c.weighty = 0;								// no vertical weight
        add(statusbar, c);							// add the status bar to the panel

		validate();									// validate the contents
        
        editorPane.setFocusable(true);				// setup the editor to receive focus
        editorPane.addKeyListener(this);			// add the keyboard listener
        
        /*
         * Had problems setting up a JTextPane (be it JTextPane, JTextArea, or JEditorPane) to receive focus using
         * [object].requestFocus().  Found a comment here about the problem: 
         * http://www.codecomments.com/archive250-2004-8-262667.html
         * 
         * It provided clues, but didn't specify how to setup the Runnable class.  So I went here:
         * http://java.sun.com/j2se/1.4.2/docs/api/java/lang/Runnable.html and setup the run() method.  Success!
         * 
         * The purpose of all of this is to direct the focus to the editor so the keyboard listener could start and
         * the user's commands would be processed.   
         */
        SwingUtilities.invokeLater(new Runnable() 	// setup another thread to run some commands
	        { 
	        	public void run() { editorPane.requestFocus(); }	// code to run:  set the focus back to the editor
	        });												
         

	}  // end private void setupPanel()
	

	private JTextArea createJEditorPane() 
	{
		JTextArea editorPane = new JTextArea();
        editorPane.setBackground(Color.BLACK);
        editorPane.setForeground(Color.LIGHT_GRAY);
        editorPane.setEditable(false);
//        editorPane.setContentType("text/html"); // text/html
        
        // enable word wrapping: http://javaalmanac.com/egs/javax.swing.text/ta_Wrap.html
        editorPane.setLineWrap(true);
        editorPane.setWrapStyleWord(true);
        return editorPane;
    }  // end private JEditorPane createEditorPane()
	
	
	/**
	 * Load the specified file and parse it.  While parsing, populate a graph.  The graph will represent the game's 
	 * rooms.  Each room will contain an array of edges which will also be determined from the specified file.
	 * @param filename
	 */
	public void loadFile(String filename)
	{
		Room room;												// keep track of the current room loaded
		castle = new Castle();									// load a new castle
		String line = new String();								// keep track of the line we're reading from the file
		int task = 0;											// keep track of the current task we're on
		String[] field;											// used for parsing the text file input
		
    	try
    	{
		    FileReader reader = new FileReader(filename);		// setup a file reader object
		    Scanner in = new Scanner(reader);					// setup a scanner to read the file
		    while(in.hasNext())									// process all the lines in the file
		    {
		    	line = in.nextLine();							// read in one line
		    	if(line.equals("99"))							// 99 is the delimiter for each section
		    		task++;										// time to start the next task
		    	
    			if(!line.equals("99"))
    			{
			    	switch(task)
			    	{
			    		case 0:										// room number and room name
			    			field = line.split(" ", 2);	// split the line
			    			room = castle.addRoom(Integer.parseInt(field[0]) - 1, field[1]);			// add a room
			    			if(field[1].equals("Entrance Hall"))
			    				player.setCurrentRoom(room);
			    			break;
			    		case 1:
			    			field = line.split(" ");		// split the line
			    			// add the arc
			    			castle.addArc(field[2], Integer.parseInt(field[0]) - 1, Integer.parseInt(field[1]) - 1);	
			    			break;
			    		case 2:
			    			// TODO:  Add code to load up the items for the rooms!
			    			break;
			    	}  // end switch(task)
    			}  // end if(line != "99")
		    }  // end while(line = in.nextLine())
		    
		    // if we got this far, then the file is done
		    // build the adjacency matrix (build now since we know how many rooms we have)
		    castle.buildMatrix();
		    
    	}  // end try
    	catch (IOException exception)							// check if there was a problem
    	{
    	    System.out.println ("Error processing file: " + exception);		
    	}  // end catch (IOException exception)		
	}  // end public void loadFile(String filename)
	
	
	
	/**
	 * Print a string to the display.  Add a carriage return after it.
	 * 
	 * @param sText String containing the message to display.
	 */
	public void printMessage(String sText)
	{
		editorPane.setText(editorPane.getText() + sText + "\n");
//		editorPane.setText(editorPane.getText() + sText + "\n" + CURSOR);
	}  // end private void printMessage()

	
	/**
	 * Provide debug output to the user interface.  To be used to verify the quality of the castle/rooms (aka: graph). 
	 */
	private void debug()
	{
		printMessage(castle.debug());
	}  // end private void debug()
	

	/**
	 * Monitor for key typed.  This actually is looking for special keys like the Window key and such.
	 * 
	 * @see java.awt.event.KeyListener#keyTyped(java.awt.event.KeyEvent)
	 */
	public void keyTyped(KeyEvent e) 
	{
		// do nothing
	}  // end public void keyTyped(KeyEvent e)

	/**
	 * Handles key presses.  Upon receiving notice of a key press, figure out which key was pressed and take action
	 * if necessary.
	 * 
	 * @see java.awt.event.KeyListener#keyPressed(java.awt.event.KeyEvent)
	 */
	public void keyPressed(KeyEvent e) 
	{
		int key = e.getKeyCode();
		
		if(key > 64 && key < 91)									// key is in A-Z (uppercase) range
		{
			editorPane.setText(editorPane.getText() + e.getKeyChar() + "\n");
			switch(key)													// Monitor the integer ASCII keyed value
			{
				case 81:												// Q - Quit
					System.exit(0);										// exit!  TODO: Confirm desire to exit w/dialog box
					break;
					
				case 68:												// D - debug
					debug();											// do debug
					showCursor();
					break;
				
				case 78:												// N - north
				case 69:												// E - east
				case 83:												// S - south
				case 87:												// W - west
					makeMove((char) key);								// perform the move, if possible 
					break;
					
				default:												// key press wasn't found.  
					editorPane.setText(editorPane.getText() + CURSOR);
					System.out.println("Pressed: [" + key + "] " + e.getKeyChar());
					break;
			}  // end switch(key)
		}  // end if(key > 64 && key < 91)
	}  // end public void keyPressed(KeyEvent e)

	/**
	 * Handles key releases.
	 * 
	 * @see java.awt.event.KeyListener#keyReleased(java.awt.event.KeyEvent)
	 */
	public void keyReleased(KeyEvent e) 
	{
		// do nothing
	}  // end public void keyReleased(KeyEvent e)
	
	
	/**
	 * Perform game start up procedures. 
	 */
	public void startGame()
	{
		printMessage(currentRoomInfo());					// let the user know what room they're in and what's in it
		showCursor();
	}  // end public void startGame()
	

	/**
	 * Get the current room and format the the information to let the user know where they are and what doors are
	 * available.
	 * 
	 * @return String containing the room info
	 */
	private String currentRoomInfo()
	{
		StringBuffer output = new StringBuffer();					// string buffer for holding the output string 
		Room room = player.getCurrentRoom();						// get the current room
		ArrayList arcs = castle.findArc(room);						// find all the arcs for this room

		output.append("You are in the " + room.getName() + ".\n");	// get the room name
		
		if(arcs.size() > 0)											// check the number of arcs
		{
			if(arcs.size() > 1)										// plural
				output.append("There are doors located on the ");
			else													// just one arc
				output.append("There is a door located on the ");
		}  // end if(arcs.size() > 0)								
		else														// no doors!
			output.append("There's no doors in this room.  You appear to be stuck.");
			
		for(int a = 0; a < arcs.size(); a++)						// get the arc labels (directions)
		{															// handy for showing the user where the doors are 
			if(a > 0)												// see if we're looping more than once										
				output.append(", ");								// seperate the doors with a comma
			
			output.append(castle.getDirectionFullName(((Arc) arcs.get(a)).getLabel()));	// full name of the direction
		}  // end for(int a = 0; a < arcs.length; a++)
		
		if(arcs.size() > 0)											// check if there were arcs
		{
			output.append(" side");									// complete the sentence
			if(arcs.size() > 1)										// check if there were more than 1 arc
				output.append("s");									// yup, make it plural
				
			output.append(".");										// complete the sentence
		}  // end if(arcs.size > 0)
		
		return output.toString();								// assemble the string buffer into a string & return it
	}  // end private currentRoomInfo()
	
	
	/**
	 * Show the cursor on the display 
	 */
	public void showCursor()
	{
		editorPane.setText(editorPane.getText() + CURSOR);			// display cursor
	}  // end public void showCursor()
	
	
	private void makeMove(char direction)
	{
		// is there a door to the north?  if so, set it as the current door, & update the display
		Room room = player.getCurrentRoom();						// get the current room
		Room newroom = castle.testMove(room.getRoomID(), direction);
		if(newroom != null)
		{
			player.setCurrentRoom(newroom);
			printMessage(currentRoomInfo());					// let the user know what room they're in and what's in it
		}  // end if(newroom != null)
		else
			printMessage("Try as you might, there's no door there.");
		
		showCursor();
	}  // end private void makeMove(char direction)
	
}  // end public class AdventureGame extends JPanel
