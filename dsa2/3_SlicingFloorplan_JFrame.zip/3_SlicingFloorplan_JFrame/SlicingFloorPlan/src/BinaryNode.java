
public class BinaryNode 
{
	private BinaryNode leftNode;			
	private BinaryNode rightNode;
	private char data;
	
	public BinaryNode(char nodeData)
	{
		data = nodeData;
		
		// currently, the node doesn't have any children
		leftNode = null;
		rightNode = null;
	}  // end public BinaryNode()
	
	public void insert(char insertValue)
	{
		if(leftNode == null)
		{
			leftNode = new BinaryNode(insertValue);
		}  // end if(leftNode == null)
		else
			rightNode = new BinaryNode(insertValue);
			
	}  // end public void insert(char insertValue)
	
	public void insertLeft(char insertValue)
	{
		// check if the left node is null
		
		if(leftNode == null)
		{
			System.out.println("Adding new left node: " + insertValue);
			leftNode = new BinaryNode(insertValue);
		}  // end if(leftNode == null)
		else
		{
			System.out.println("Just inserting a left node: " + insertValue + " for " + data);
			leftNode.insertLeft(insertValue);
		}  // end else
	}  // end public void insert(Object insertValue)

	public void insertRight(char insertValue)
	{
		// check if the left node is null
		
		if(rightNode == null)
		{
			System.out.println("Adding new right node: " + insertValue);
			rightNode = new BinaryNode(insertValue);
		}  // end if(leftNode == null)
		else
		{
			System.out.println("Just inserting a right node: " + insertValue + " for " + data);
			rightNode.insertRight(insertValue);
		}  // end else
	}  // end public void insert(Object insertValue)

	
	public void setLeftNode(BinaryNode node)
	{
		leftNode = node;
	}  // end public void setLeftNode(BinaryNode node)
	
	public void setRightNode(BinaryNode node)
	{
		rightNode = node;
	}  // end public void setLeftNode(BinaryNode node)
	
	public BinaryNode getLeftNode()
	{
		return leftNode;
	}  // end public BinaryNode getLeft()

	public BinaryNode getRightNode()
	{
		return rightNode;
	}  // end public BinaryNode getLeft()
	
	
	public char getData()
	{
		return data;
	}  // end public char getData()
	
	
	public void addNode(BinaryNode node)
	{
		if(leftNode == null)
			setLeftNode(node);
		else
			setRightNode(node);
	}  // end public void addNode()

}  // end public class BinaryNode
