import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.net.MalformedURLException;
import java.io.*;
import java.util.Scanner;
import java.net.URL;


public class InputFrame extends JFrame
{
	private static final String sTitle = "Slicing Floorplan";
	private static final long serialVersionUID = 1L;
	private JPanel textControlsPane;
	private JTextField textInFile;
	private JTextField textInput;
	private String floorplan;
	
	/**
	 * @param args
	 */
	public InputFrame() 
	{
		super(sTitle);
		setLayout(new BorderLayout());

		textInFile = new JTextField(10);
		textInput = new JTextField(10);
		JLabel labelInFile = newTextFieldLabel(textInFile, "File: ");
		JLabel labelFloorplan = newTextFieldLabel(textInput, "Floor Plan: ");

		textControlsPane = new JPanel();
	    GridBagLayout gridbag = new GridBagLayout();
	    GridBagConstraints c = new GridBagConstraints();
	    
	    textControlsPane.setLayout(gridbag);		
	
	    c.anchor = GridBagConstraints.WEST;
		c.gridwidth = GridBagConstraints.REMAINDER;     //end row
		c.weighty = 1.0;
		JLabel textMsgLabel = new JLabel("Generate a floor plan from a file:");
	    textControlsPane.add(textMsgLabel, c);

	    JButton buttonInFile = new JButton("File...");
	    ButtonFileHandler buttonFileHandler = new ButtonFileHandler();
	    buttonFileHandler.textField = textInFile;
	    buttonInFile.addActionListener(buttonFileHandler);
	    
	    
	    JButton[] buttons = {buttonInFile};
	    JLabel[] labels = {labelInFile};
	    JTextField[] textFields = {textInFile};
	    addLabelTextRows(labels, textFields, buttons, gridbag, textControlsPane);
	    
		textMsgLabel = new JLabel("Or enter the floor plan:");
	    textControlsPane.add(textMsgLabel, c);
	    
		c.gridwidth = GridBagConstraints.WEST;  // RELATIVE; 		//next-to-last
		c.ipady = 20;									// change the height y padding
		c.fill = GridBagConstraints.NONE;      			//reset to default
		c.weightx = 0.0;                       			//reset to default
		textControlsPane.add(labelFloorplan, c);

		c.ipady = 0;									// change the height y padding
		c.gridwidth = GridBagConstraints.REMAINDER;     //end row
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 2.0;
		textControlsPane.add(textInput, c);
	    
	
		c.fill = GridBagConstraints.NONE;
	    c.gridwidth = GridBagConstraints.REMAINDER; //last
	    c.anchor = GridBagConstraints.WEST;
	    c.weightx = 1.0;
	    textControlsPane.setBorder(
	            BorderFactory.createCompoundBorder(
	                            BorderFactory.createTitledBorder("Slicing Floorplan"),
	                            BorderFactory.createEmptyBorder(5,5,5,5)));
	    
	    // setup the button
	    c.anchor = GridBagConstraints.CENTER;
	    JButton buttonSubmit = new JButton("Submit");
	    textControlsPane.add(buttonSubmit, c);
	    
	    add(textControlsPane, BorderLayout.PAGE_START);
	
	    // setup the listener for the button
	    ButtonHandler handler = new ButtonHandler();
	    buttonSubmit.addActionListener(handler);
	    
	    textInFile.requestFocus();
	    // for testing only
//	    textInput.setText("|-AB-|C-EFD");
	    textInput.setText("!-AB|CD");
	}  // end public InputFrame()
	

	/**
	 * Paint the current window. 
	 *  
	 * @see java.awt.Component#paint(java.awt.Graphics)
	 */
	public void paint(Graphics g)
	{
		super.paint(g);								// paint the window
	}  // end public void paint(Graphics g)

	
	
	private JLabel newTextFieldLabel(JTextField textField, String label)
	{
		JLabel textLabel = new JLabel(label);
		textLabel.setLabelFor(textField);
		return textLabel;
	}  // end private void newTextField(JTextField textField, String label)


	private class ButtonHandler implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			String sMsg = validateInput();
			if(sMsg != "") {
				JOptionPane.showMessageDialog(textControlsPane, sMsg);
				return;
			}  // end if(sMsg != "") {

		
			textControlsPane.setVisible(false);
			
			FloorPlanBuilder floorplanbuilder = new FloorPlanBuilder(floorplan);
			add(floorplanbuilder);
			validate();
			
			
//			IDColumns idColumn = new IDColumns();
//			add(idColumn.getPane(textInFile.getText(), textOutFile.getText()));
		    // setup the listener for the button
//		    ButtonFieldHandler handler = new ButtonFieldHandler();
//		    idColumn.buttonSubmit.addActionListener(handler);
			
//			Sitecode sitecode = new Sitecode();
//			String sSitecode = sitecode.calculate(textCompany.getText(), textCountry.getText(), textZip.getText());
//			textResults.setText("Sitecode: " + sSitecode);

		}  // end public void actionPerformed(ActionEvent event) {
	}  // end private class ButtonHandler implements ActionListener {

	
	private class ButtonFileHandler implements ActionListener {
		private JTextField textField;
		
		public void actionPerformed(ActionEvent event) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(null);

            if(result == JFileChooser.APPROVE_OPTION)
            {
                URL fileURL = null;
                try
                {
                    fileURL = fileChooser.getSelectedFile().toURL();
                }  // end try
                catch(MalformedURLException malformedURLException)
                {
                    System.err.println("Could not create URL for the file");
                }  // end catch(MalformedURLException malformedURLException)
                
                if(fileURL != null)
                	textField.setText(fileChooser.getSelectedFile().toString());
            }  // end if(result == JFileChooser.APPROVE_OPTION)
            
		}  // end public void actionPerformed(ActionEvent event) {
	}  // end private class ButtonHandler implements ActionListener {
	
	
	private String validateInput() {
		String sMsg = "";
		String filename = textInFile.getText();
		
		if(filename.length() < 1 && textInput.getText().length() < 1)
			sMsg = "You must specify the file name or specify the floor plan.\n";
		
		// if the user specified a file, was it valid?
		if(filename.length() > 0)
			if(!testFile(textInFile.getText()))
				sMsg = "Unable to read the file you specified.  Please try a different file name.";
			else												// the file is valid
				floorplan = getFloorPlanFromFile(filename);		// retrieve the floorplan
		else
			if(textInput.getText().length() > 0)				// check if the user entered the floorplan
				floorplan = textInput.getText();				// yup, assign it while we're here
		
		return sMsg;		
	}  // end private String validateInput(String sCountry) {
	
	
    private void addLabelTextRows(JLabel[] labels, JTextField[] textFields, 
    		JButton[] buttons, GridBagLayout gridbag, Container container) 
    {
		GridBagConstraints c = new GridBagConstraints();
		c.anchor = GridBagConstraints.EAST;
		int numLabels = labels.length;
		
		for (int i = 0; i < numLabels; i++) 
		{
			c.gridwidth = GridBagConstraints.WEST;  // RELATIVE; 		//next-to-last
			c.ipady = 20;									// change the height y padding
			c.fill = GridBagConstraints.NONE;      			//reset to default
			c.weightx = 0.0;                       			//reset to default
			container.add(labels[i], c);

			c.ipady = 0;									// change the height y padding
//			c.gridwidth = GridBagConstraints.REMAINDER;     //end row
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1.0;
			container.add(textFields[i], c);
			
			c.weightx = 0.0;
			c.gridwidth = GridBagConstraints.REMAINDER;     //end row
		    container.add(buttons[i], c);
		}
	}  // end private void addLabelTextRows(JLabel[] labels, JTextField[] textFields, GridBagLayout gridbag, Container container) {
    
    
    private String getFloorPlanFromFile(String filename)
    {
    	try
    	{
		    FileReader reader = new FileReader(filename);
		    Scanner in = new Scanner(reader);
		    return in.nextLine();
    	}  // end try
    	catch (IOException exception)
    	{
    	    System.out.println ("Error processin file: " + exception);
    	    return "Error reading file";
    	}  // end catch (IOException exception)
    }  // end private String getFloorPlanFromFile(String filename)
    
    private boolean testFile(String filename)
    {
		FileInputStream oStream;
    	
		try
		{
			oStream = new FileInputStream(filename);
			oStream.close();
		}  // end try
		catch(FileNotFoundException FileNotFoundException)
		{
			// System.err.println("Could not find the file.");
			return false;
		}  // end catch(FileNotFoundException FileNotFoundException)
		catch(IOException IOException)
		{
			// System.err.println("Error reading the file.");
			return false;
		}  // end catch(IOException IOException)
		
		return true;
    }  // end private boolean testFile(String filename)

}  // end public class InputFrame
