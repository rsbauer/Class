/**
 * 
 */
import javax.swing.JFrame;

/**
 * @author rbauer
 * @version 1.0  2005-OCT-14
 */
public class FloorPlan 
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
	    InputFrame inputFrame = new InputFrame();
	    inputFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    inputFrame.setSize(500, 400);
	    inputFrame.setVisible(true);		
	}  // end public static void main(String[] args)
}  // end public class FloorPlan
