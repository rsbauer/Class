import javax.swing.*;
import java.awt.*;

public class FloorPlanBuilder extends JPanel
{
	private static final long serialVersionUID = 1L;
	private Dimension dimension;
	private String floorplan;
	
	public FloorPlanBuilder()
	{
		setupPanel();
	}  // end public FloorPlanBuilder()

	public FloorPlanBuilder(String givenfloorplan)
	{
		setupPanel();
		floorplan = givenfloorplan;
		BinaryTree tree = new BinaryTree();
		tree.loadTree(floorplan);

		if(tree.getRoot().getLeftNode() == null)
			System.out.println("Left node is null");
		else
			System.out.println("Left node is " + tree.getRoot().getLeftNode().getData());
		
		System.out.println("** ** **");
		tree.inorderTraversal();
		System.out.println("Node count: " + tree.nodeCount());

	}  // end public FloorPlanBuilder(String givenfloorplan)
	
	
	private void setupPanel()
	{
		setOpaque(true);	// handy for clearing the panel successfully (otherwise get artifacts) 
		setBackground(Color.WHITE);				// set the background color
	}  // end private void setupPanel()
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);		// call super's paint method
		Graphics2D g2 = (Graphics2D) g;
		dimension = getSize();
		
//		g2.drawRect(dimension.width/2, dimension.height/2, 90, 55);
		drawStatusBar(g2);
	}  // end public void paintComponent(Garphics g)
	
	
	private void drawStatusBar(Graphics2D g)
	{
		final int STATUSBARHEIGHT = 12;
		
		g.setColor(new Color(225, 235, 244));		// set the status bar color (light blue)
		// clear the bottom of the screen
		g.fillRect(0, dimension.height - STATUSBARHEIGHT, dimension.width, dimension.height);	
		g.setColor(Color.BLACK);									// color for the text
		// status bar text (let the user know the dimension and level used/entered
		String statusText = new String("Given Floorplan: " + floorplan);
		g.drawString(statusText, 2, dimension.height - 2);	// draw the string (place it at the bottom)		
	}  // end private void drawStatusBar()
	
	
	// http://www-1g.cs.luc.edu/~glance/Fall01/271/Assignments/7/Preorder.java
	// http://64.233.167.104/search?q=cache:1wCQMhd-AxkJ:www.cs.luc.edu/~glance/Fall01/271/Assignments/7/a7.html+java+preorder+binary+tree+-traversal+-search&hl=en
	private BinaryTree loadTree_Old(String plan)
	{
/*		
		BinaryNode node1 = new BinaryNode('|');
		BinaryNode node2 = new BinaryNode('-');
		BinaryNode node3 = new BinaryNode('A');
		BinaryNode node4 = new BinaryNode('B');
		BinaryNode node5 = new BinaryNode('-');
		BinaryNode node6 = new BinaryNode('|');
		BinaryNode node7 = new BinaryNode('C');
		BinaryNode node8 = new BinaryNode('-');
		BinaryNode node9 = new BinaryNode('E');
		BinaryNode node10 = new BinaryNode('F');
		BinaryNode node11 = new BinaryNode('D');

		tree.setRoot(node1);
		
		node1.setLeftNode(node2);
		node2.setLeftNode(node3);
		node2.setRightNode(node4);
		

		node5.setLeftNode(node6);
		node6.setLeftNode(node7);
		node8.setLeftNode(node9);
		
		node1.setRightNode(node5);
		node6.setRightNode(node8);
		node8.setRightNode(node10);
		node5.setRightNode(node11);
		
*/
		
		BinaryTree tree = new BinaryTree();
		tree.insertNode(plan.charAt(0));
		
		BinaryTree tree2 = new BinaryTree();
		tree2.insertNode(plan.charAt(1));
		
		tree2.insertNode(plan.charAt(2));
		tree2.insertNode(plan.charAt(3));
		
		tree.getRoot().setLeftNode(tree2.getRoot());
		return tree;
	}  // end private void loadTree()
	

	private BinaryTree loadTree(BinaryTree tree, String plan)
	{
		System.out.println(plan);
		if(plan.length() > 0)
		{
			char character = plan.charAt(0);
			// tree.insertNode(character);
			if(character == '-' || character == '|')
			{
/*				
				BinaryTree newtree = new BinaryTree();
				newtree.insertNode(character);
				tree.insertNode(loadTree(newtree, plan.substring(1)).getRoot());
				return newtree;
*/
				BinaryTree newtree = new BinaryTree();
				newtree.insertNode(character);
				newtree = loadTree(newtree, plan.substring(1));
				
				if(tree.getRoot() == null)
					tree = newtree;
				else
					tree.getRoot().addNode(newtree.getRoot());
				return tree;
			}  // end if(character == '-' || character == '|')
			else
			{
				System.out.println("Working with " + tree.getRoot().getData());
				tree.insertNode(character);
				return loadTree(tree, plan.substring(1));
			}  // end else
		}  // end if(plan.length() > 0)
		
		return tree;
	}  // end private BinaryTree loadTree_Old(String plan)
	
	
}  // end public class FloorPlanBuilder
