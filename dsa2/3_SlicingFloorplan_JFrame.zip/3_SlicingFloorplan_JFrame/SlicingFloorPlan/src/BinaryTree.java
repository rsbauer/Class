
public class BinaryTree 
{
	private BinaryNode root;
	private int nodecount;
	private boolean right;
	
	public BinaryTree()
	{
		root = null;
		nodecount = 0;
		right = false;
	}  // end public BinaryTree()
	

/*	
	public void insertNode(char insertValue)
	{
		if(root == null)
		{
			root = new BinaryNode(insertValue);
		}  // end if(root == null)
		else
		{	
			System.out.println("Node for " + root.data + " -> " + insertValue);
			root.insert(insertValue);
		}  // end else
		
		nodecount++;
	}  // end public void insert(Object insertValue)

*/	
	
	public void insertNode(char insertValue)
	{
		if(root == null)
		{
			root = new BinaryNode(insertValue);
		}  // end if(root == null)
		else
		{
			if(root.getLeftNode() == null)
				root.insertLeft(insertValue);
			else
				root.insertRight(insertValue);
		}  // end else
		
		nodecount++;
	}  // end public void insert(Object insertValue)
	
	
	public void insertNode(BinaryNode node)
	{
		if(root == null)
		{
			root = new BinaryNode(node.getData());
		}  // end if(root == null)
		else
		{
			if(root.getLeftNode() == null)
				root.insertLeft(node.getData());
			else
				root.insertRight(node.getData());
		}  // end else
		
		nodecount++;
	}  // end public void insert(Object insertValue)	
	
	
	public void insertNodeLeft(char insertValue)
	{
		if(root == null)
		{
			root = new BinaryNode(insertValue);
		}  // end if(root == null)
		else
		{	
			System.out.println("Node for " + root.getData() + " -> " + insertValue);
			root.insertLeft(insertValue);
		}  // end else
		
		nodecount++;
	}  // end public void insertNodeLeft(char insertValue)
	
	
	public void insertNodeRight(char insertValue)
	{
		if(root == null)
		{
			root = new BinaryNode(insertValue);
		}  // end if(root == null)
		else
		{	
			System.out.println("Node for " + root.getData() + " -> " + insertValue);
			root.insertRight(insertValue);
		}  // end else
		
		nodecount++;
	}  // end public void insertNodeLeft(char insertValue)
	
	
	public void setRoot(BinaryNode node)
	{
		root = node;
	}  // end public void setRoot(BinaryNode node)
	
	
	public BinaryNode getRoot()
	{
		return root;
	}  // end public BinaryNode getRoot()
	
	
	public void inorderTraversal()
	{
		inorder(root);
	}  // end public void inorderTraversal()
	
	
	private void inorder(BinaryNode node)
	{
		if(node == null)
			return;
		
		inorder(node.getLeftNode());						// traverse the left side of the tree
		System.out.println(node.getData());				// the root node data
		inorder(node.getRightNode());					// traverse the right side of the tree
	}  // end private void inorder(BinaryNode node)
	
	
	public int nodeCount()
	{
		return nodecount;
	}  // end public int nodeCount()
	
	
	public boolean isEmpty()
	{
		if(nodecount == 0)
			return true;
		return false;
	}  // end public boolean isEmpty()
	
	
	public void addCompleteNode(char rootchar, BinaryNode left, BinaryNode right)
	{
		root = new BinaryNode(rootchar);
		root.setLeftNode(left);
		root.setRightNode(right);
	}  // end public void addCompleteNode(char root, BinaryNode left, BinaryNode right)
	
	
	public void addNode(char character)
	{
		if(root.getLeftNode() == null)
			root.setLeftNode(new BinaryNode(character));
		else
			if(root.getRightNode() == null)
				root.setRightNode(new BinaryNode(character));
			else
				System.out.println("UH OH!!");
				// root.insert(character);		// not sure this line is correct
	}  // end public void addNode(char character)
	
	
	public void addNode(BinaryNode node)
	{
		if(root == null)
		{
			root = node;
			return;
		}  // end 
		
		if(root.getLeftNode() == null)
			root.setLeftNode(node);
		else
			if(root.getRightNode() == null)
				root.setRightNode(node);
			else
			{
				System.out.println("UH OH 2!! " + node.getData() + " -> " + node.getLeftNode().getData() + " / " + node.getRightNode().getData() + " :: " + root.getData() + " : " + root.getLeftNode().getData() + " / " + root.getRightNode().getData());
				// root.addNode(node);
			}  // end else
	}  // end public void addNode(BinaryNode node)
	
	
	public void loadTree_OLD(String plan)
	{
		if(plan.length() > 0)
		{
			char character = plan.charAt(0);
			if(character == '|' || character == '-')
			{
				BinaryTree newtree = new BinaryTree();						// create a new tree
				newtree.insertNode(character);								// add the current char as the root node
				newtree.loadTree(plan.substring(1));						// load this new tree up

//				System.out.println("** ** ** " + getRoot().getData() + " (" + plan + ") ** ** **");
//				inorderTraversal();
				
				// problem is below!
				addNode(newtree.getRoot());
			}  // end if(character == '|' || character == '-')
			else
			{	
				addNode(character);											// add a leaf node
				loadTree(plan.substring(1));								// continue parsing the string and loading the tree
			}  // end else
		}  // end if(plan.length() > 0)
	}  // end public void loadTree(String plan)

	
	public void loadTree(String plan)
	{
		root = loadTreeNodes(plan);
	}  // end public void loadTree(String plan)
	
	
	public BinaryNode loadTreeNodes(String plan)
	{
		if(plan.length() > 0)
		{
			char character = plan.charAt(0);
			if(character == '|' || character == '-' || character == '!')
			{
				BinaryTree newtree = new BinaryTree();						// create a new tree
				newtree.insertNode(character);
				newtree.loadTreeNodes(plan.substring(1));
				
				addNode(newtree.getRoot());
				return root;
			}  // end if(character == '|' || character == '-')
			else
			{
				addNode(character);
				loadTreeNodes(plan.substring(1));
			}  // end else
		}  // end if(plan.length() > 0)
		
		return root;
	}  // end public BinaryNode loadTreeNodes(String plan)

	
}  // end public class BinaryTree
